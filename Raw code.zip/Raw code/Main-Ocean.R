options(java.parameters = "-Xmx24g")
library(xlsx)
library(readxl)
library(hydroGOF)  #已被移除------笔记本迁移
library(randomForest)
library(ggplot2)
library(circlize)
library(RColorBrewer)
library(dplyr) #冲突pdp注意！
library(randomForestExplainer)
library(pdp)
library(tcltk)
#library(ggepi)
library(patchwork)
library(caret)
library(ggrepel)
library(data.table)
library(ggraph)
library(igraph)
library(tidyverse)
library(RColorBrewer) 
library(pdp)

#####################################################################
#####                    data info (necessary)                  #####
#####################################################################
#label1<-excel_sheets('C:/Users/dell/Desktop/Ocean-code-R/10.19-Ocean-data.xlsx')
#label1<-excel_sheets('C:/Users/dell/Desktop/Ocean-code-R/11-18-Ocean-data.xlsx')
#label1<-excel_sheets('G:/Ocean-final/12-10-Ocean-data-删除Predation.xlsx')

label1<-excel_sheets('G:/Ocean-final2/12-10-Ocean-data.xlsx')
label<-c(label1)
colindex<-c('Human','MPs','Predation','POC','Salinity','Tem','LatV','LonV',
            'Mix','chl','Fe','NO3','O2','pH','phosphate','silicate','Rns',
            'RnL','DIC','DOC','Index')

#colindex<-c('Human','MPs','POC','Salinity','Tem','LatV','LonV',
#            'Mix','chl','Fe','NO3','O2','pH','phosphate','silicate','Rns',
#            'RnL','DIC','DOC','Index')


#####################################################################
#####                    RF analysis                            #####
#####################################################################
#setwd('C:/Users/dell/Desktop/Ocean-code-R')
setwd('G:/Ocean-final2')

rf.list<-list()

for (i in 1:2){
  #data<-read.xlsx('10.19-Ocean-data.xlsx',i,header=TRUE)
  data<-read.xlsx('12-10-Ocean-data.xlsx',i,header=TRUE)
  colnames(data)<-colindex
  # train<-read.xlsx('Ocean-data-R.xlsx',i)$X0
  # data_train<-data[train,]
  # data_test<-data[-train,]
  seed<-rep(1,2)
  set.seed(seed[i])
  rf.list[[label1[i]]]<-local({
    data=data
    randomForest(Index~.,data=data,importance=TRUE,proximity=T,ntree=500,mtry=6)    #model
  })
  rf<-rf.list[[label[i]]]
  pre_train<-predict(rf)
  cor_train<-cor(pre_train,data$Index)
  #rmse_train<-rmse(pre_train,data$Index)
  # pre_test<-predict(rf,data_test[,1:(ncol(data_test)-1)])
  # cor_test<-cor(pre_test,data_test$Index)
  # rmse_test<-rmse(pre_test,data_test$Index)
  print(cor_train)
  # print(cor_test)
}

save(rf.list,file='Rda/rflist.rda')
#----------------------------------------------
# Importance analysis
#----------------------------------------------
# multi-way importance analysis
md<-list()
mi<-list()
colindexf<-factor(colindex[-21],levels=colindex[-21])  #不删除特征是21
impframe<-data.frame(index=colindexf)
for (i in 1:2){
  print(i)
  rf<-rf.list[[i]]
  imp<-importance(rf)
  incmse<-data.frame(index=names(imp[,2]),incmse=imp[,1]/max(imp[,1]))
  colnames(incmse)[2]<-paste0(i)
  impframe<-merge(impframe,incmse,by='index',all=T)

  min_depth_frame<-min_depth_distribution(rf)
  md[[label[i]]]<-min_depth_frame

  im_frame<-measure_importance(rf)
  im_frame[4]<-im_frame[4]/max(im_frame[4])
  im_frame[5]<-im_frame[5]/max(im_frame[5])
  mi[[label[i]]]<-im_frame
}
colnames(impframe)[1:2]<-label
save(impframe,md,mi,file='Rda/multi-importance.rda')

##############################################################################################################
# importance plot ----->  Fig.6 A+B

load(file='Rda/rflist.rda')
load(file='Rda/multi-importance.rda')
mdplot<-list()
miplot<-list()

for (i in 1:2){
  print(i)
  min_depth_frame<-md[[i]]
  mdplot[[label[i]]]<-local({
    min_depth_frame=min_depth_frame
    plot_min_depth_distribution(min_depth_frame,k=14)+
      theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank())
      theme(legend.title = element_text(size=rel(0.6)),
            legend.text = element_text(size=rel(0.5)))    #原先开头---legend.key.size = unit(0.5,'line'),----
  })
  ggsave(paste0('A',label[i],'.pdf'),width=7,height=7)   #Fig.6 B    #图例大小记得调整

  im_frame=mi[[i]]
  im_frame$p_value<-im_frame$p_value/5
  miplot[[label[i]]]<-local({
    im_frame=im_frame
    plot_multi_way_importance(im_frame, x_measure = "mse_increase",
                              y_measure = "node_purity_increase",
                              size_measure = "p_value", no_of_labels = 5)+
      theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank())+
      theme(axis.line=element_line(color='black'),
            axis.ticks.length=unit(0.4,'line'))+
      coord_fixed(ratio=1)+
      theme(legend.key.size = unit(1,'line'),legend.position=c(0.15,0.75))+ #加了上面那句限制图例行间距,且位置要多次调整
      scale_x_continuous(limits = c(0,1), breaks = seq(0,1, by = 0.25)) +     # 设置x轴范围和刻度间隔
      scale_y_continuous(limits = c(0,1), breaks = seq(0,1, by = 0.25))       # 设置y轴范围和刻度间隔
  })
  ggsave(paste0('Ocean',label[i],'.pdf'),width=3,height=3)   #Fig.6 A
}
save(mdplot,miplot,file='Rda/importanceplot.rda')


#--------------------------------------------------------------------------------------------------
# Feature Interaction Calculate  Fig.7 B
#--------------------------------------------------------------------------------------------------
load(file='Rda/rflist.rda')
load(file='Rda/multi-importance.rda')

inter_list<-list()
for (i in 1:2){
  print(i)
  im_frame<-mi[[i]]
  rf<-rf.list[[i]]
  vars <- important_variables(im_frame, k = 5, measures = c("mean_min_depth","no_of_trees"))
  interactions_frame <- min_depth_interactions(rf, vars)
  interactions_frame <- arrange(interactions_frame,-interactions_frame[,4])
  inter_list[[label[i]]]<-interactions_frame
  #load(paste0('Rda/inter_',Label[i+2],'.rda'))
  #head(interactions_frame[order(interactions_frame$occurrences, decreasing = TRUE), ])
}
save(inter_list,file='Rda/inter1.rda')

fiplot<-list()
for (i in 1:2){
  interactions_frame<-inter_list[[i]]
  hlim<-ceiling(max(interactions_frame[1:25,3],interactions_frame[1:25,6]))
  fip<-plot_min_depth_interactions(interactions_frame,k=25)+
        scale_y_continuous(limits=c(0,hlim+1.5),expand=c(0,0))+
        scale_fill_gradient(low='#00bfc4',high='#f8766d')+                 #换色
        theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank())   #+
        #theme(legend.position=c(0.3,0.6),legend.box="horizontal")  #(0.3,0.8),图例大小要调整，或者画在外面
  fiplot[[label[i]]]<-fip
  ggsave(paste0('绘图记录/交互作用/',label[i],'.pdf'),width=8,height=4)
}

save(fiplot,file='Rda/inter_plot.rda')

#----------------------------------------------
# Feature Interaction Calculate   新公式的计算？
#----------------------------------------------
source('min_depth_distribution.R')
source('measure_importance.R')
source('min_depth_interactions.R')
source('interaction.R')
rdlist<-list()
r_interaction<-list()
pb <- tkProgressBar("?ܽ???","?????? %", 0, 100) 
for (i in 1:length(label)){
  print(paste0(i,'/',length(label)))
  info<- sprintf("?????? %d%%", round(i*100/length(label))) 
  rf<-rf.list[[i]]
  c1<-rep(1:length(colindex),each=length(colindex))
  c11<-colindex[c1]
  c2<-rep(1:length(colindex),length(colindex))
  c22<-colindex[c2]
  rd_frame<-data.frame(c11,c22)
  colnames(rd_frame)=c('variable','root_variable')
  im_frame<-mi[[i]]
  rd_frame<-merge(rd_frame,im_frame[c(1,6)],all.x=T)
  
  pb1 <- tkProgressBar("??????","?????? %", 0, 100) 
  for (j in 1:rf$ntree){
    info1<- sprintf("?????? %d%%", round(j*100/rf$ntree)) 
    D<-calculate_max_depth(rf,j)
    interactions_frame_single<-min_depth_interactions_single(rf,j,colindex)
    rD<-calculate_rD(D,interactions_frame_single,j)
    rD<-cbind(interactions_frame_single[1:2],rD)
    rd_frame<-merge(rd_frame,rD,by=c('variable','root_variable'),all=T)
    setTkProgressBar(pb1, j*100/rf$ntree, sprintf("???? (%s)", info1),info1) 
  }
  close(pb1)
  
  rd_frame[is.na(rd_frame)]<-0
  rdlist[[label[i]]]<-rd_frame
  for (k in 1:nrow(rd_frame)){
    rd_frame[k,504]<-sum(rd_frame[k,4:503])/rd_frame[k,3]
  }
  r_frame<-rd_frame[c(1,2,504)]
  colnames(r_frame)<-c("variable" , "root_variable" ,"r")
  r_interaction[[label[i]]]<-r_frame
  #save(rd_frame, file = paste0("Rda/rd_frame_",label[i],".rda"))
  #save(r_frame,file = paste0("Rda/r_frame_",label[i],".rda"))
  setTkProgressBar(pb, i*100/length(label), sprintf("?ܽ??? (%s)", info),info) 
}
close(pb)
save(r_interaction,file='Rda/r-interaction.rda')
#----------------------------------------------
# Node and Edge files
#----------------------------------------------
load(file='Rda/r-interaction.rda')
load(file='Rda/multi-importance.rda')

type<-data.frame(label=c(colindex[-21],label),  #原来是21
                 type=c(rep('M',15),rep('A',2),rep('E',3),rep('y',2)),
                 color=c(rep('#98dbef',15),rep('#a4e192',2),rep('#ffc177',3),
                         rep('#ffb6d4',2)))

for (i in 1:length(label)){
  nodes<-data.frame(id=c(1:length(colindex)),label=c(colindex[-21],label[i]))
  nodes<-merge(nodes,type,all.x=T)
  nodes<-arrange(nodes,nodes['id'])
  write.csv(nodes,paste0('network/nodes_',label[i],'.csv'),row.names=FALSE,fileEncoding='UTF-8')
  
  r_frame<-r_interaction[[i]]
  edges<-cbind(r_frame,c(rep('x-x',nrow(r_frame))))
  colnames(edges)<-c('Source','Target','Weight','Type')
  edges[is.na(edges)]<-0
  edges[3]<-edges[3]/max(edges[3])
  edges[3][edges[3]<0.5]<-0
  edges<-edges[-which(edges[3]==0),]
  edges<-edges[-which(edges[1]==edges[2]),]
  for (j in 1:nrow(edges)){
    j1<-which(edges[j,1]==edges[2])
    j2<-which(edges[j,2]==edges[1])
    j3<-intersect(j1,j2)
    if (length(j3)!=0){
      edges[j,3]<-mean(c(edges[j,3],edges[j3,3]))
      edges<-edges[-j3,]
    }
  }
  im_frame<-mi[[i]]
  if (i <13){
    x_y<-data.frame(Source=im_frame$variable,
                  Target=c(rep(label[i],20)),
                  Weight=im_frame[4],
                  Type=c(rep('x-y',20)))
  } else {
    x_y<-data.frame(Source=im_frame$variable,
                    Target=c(rep(label[i],28)),
                    Weight=im_frame[4],
                    Type=c(rep('x-y',28)))
  }
  colnames(x_y)<-c('Source','Target','Weight','Type')
  edges<-rbind(edges,x_y)
  edges[3][edges[3]<=0]<-0
  for (j in 1:nrow(nodes[1])){
    edges[edges==nodes[j,1]]<-nodes[j,2]
  }
  write.csv(edges,paste0('network/edges',label[i],'.csv'),row.names=FALSE,fileEncoding='UTF-8')
}

#----------------------------------------------
# pdp analysis-----------------------------------------这一部分单独绘制，见PDP-Ocean即可----------------------可忽略
#----------------------------------------------
load(file='Rda/inter1.rda')
pdplist<-list()
pdpplot<-list()

for (i in 1:15){
  if (i<=12){
    data<-read.xlsx('imm/RF20230520.xlsx',i+1,header=TRUE)
    colnames(data)<-colindex
    #train<-read.xlsx('imm/ss-index-all.xlsx',i)$X0
    #data_train<-data[train,]
    #data_test<-data[-train,]
    seed<-rep(1,12)
    seed[8]<-2
    seed[12]<-8
    set.seed(seed[i])
    #rf<-randomForest(Index~.,data=data_train,importance=TRUE,proximity=T,ntree=500,mtry=5)
    rf<-randomForest(Index~.,data=data,importance=TRUE,proximity=T,ntree=500,mtry=5)
  } else {
    data<-read.xlsx('burden/clearance2023-1.xlsx',i-10,header=TRUE)[-1]
    colnames(data)<-colindex[-c(2,24,25)]
    #train<-read.xlsx('burden/ss-index-all.xlsx',i-12)$X0
    #data_train<-data[train,]
    #data_test<-data[-train,]
    seed<-c(1,1,2)
    set.seed(seed[i-12])
    #rf<-randomForest(Index~.,data=data_train,importance=TRUE,proximity=T,ntree=500,mtry=5)
    rf<-randomForest(Index~.,data=data,importance=TRUE,proximity=T,ntree=500,mtry=5)
    #print('ok')
  }
  
  inter_frame<-inter_list[[i]]         #上方inter1的rda文件，记录需要读取的前四名交互特征
  j=1
  k=1
  subpdp<-list()
  subpdpplot<-list()
  while (j<=4){
    interpair<-inter_frame$interaction[k]
    v1<-strsplit(interpair,':')[[1]][1]
    v2<-strsplit(interpair,':')[[1]][2]
    k=k+1
    if (v1!=v2) {
      #par<-pdp::partial(rf,pred.var = c(v1, v2), chull = TRUE, progress = "text")   #绘图命令，凸包
      
      par<-pdp::partial(rf,pred.var = c(v1, v2), contour = TRUE, progress = "text")  #全部
      
      subpdp[[j]]<-par
      #subpdpplot[[j]]<-autoplot(par,contour = TRUE, legend.title = label[i])+
        # theme_bw()+
        # theme(legend.position=c(0.9,0.8))+
        # theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank())+
        # theme(axis.line=element_line(color='black'),
        #       axis.ticks.length=unit(0.5,'line'))
      # ggsave(paste0('plot/dvpdp/',label[i],'-',v1,'-',v2,'.pdf'),width=5,height=5)
      j<-j+1
    } else {j<-j}
  }
  print(i)
  pdplist[[label[i]]]<-subpdp
  pdpplot[[label[i]]]<-subpdpplot
}

save(pdplist,file='Rda/pdplist.rda')
save(pdpplot,file='Rda/pdpplot.rda')

################################load即可绘图##########还是要运行前面的部分##################################

for (i in 1:15){
  subpdp<-pdplist[[i]]
  for (j in 1:4){
    par<-subpdp[[j]]
    subpdpplot[[j]]<-local({
      par=par
      ggplot(par, aes(x = par[[1L]], y = par[[2L]],
                                     z = par[["yhat"]], fill = par[["yhat"]])) +
        geom_tile()+
        geom_contour(color = 'white')+
        #viridis::scale_fill_viridis(name =label[i], option = 'B') +    #D是颜色方案？
        scale_fill_gradient(low = "#00bfc4", high = "#f8766d", name = label[i]) +  #修改配色地方！@##￥
        theme_bw()+
        xlab(colnames(par)[1])+
        ylab(colnames(par)[2])+
        theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank())+
        theme(axis.text = element_text(size = rel(0.8)),
              axis.ticks.length=unit(0.3,'line'),axis.title = element_text(size = rel(0.8)))+
        #theme(legend.key.size = unit(0.5,'line'),legend.title = element_text(size=rel(0.6)),
        #      legend.text = element_text(size=rel(0.5)),legend.position = c(0.9,0.8))
        theme(legend.key.size = unit(1,'line'),legend.title = element_text(size=rel(1)),legend.title.align = 0.5,
              legend.text = element_text(size=rel(0.5)),legend.position = c(1,1),
              legend.justification = c(1, 1))  #,legend.background = element_blank()设置白色背景移除
              #legend.background = element_rect(color = "black", size = 0.3))
      
    ggsave(paste0('绘图记录draw/新配色/',label[i],'-',
                  colnames(par)[1],'-',colnames(par)[2],
                  '.pdf'),width=5,height=5)   #本来是5
    })
  }
  pdpplot[[label[i]]]<-subpdpplot
}
  
for (i in 1:15){
  part1<-miplot[[i]]+fiplot[[i]]+plot_layout(width=c(2,4.5),height=c(2,2))+plot_annotation(tag_levels = 'a')
  part2<-pdpplot[[i]][[1]]+pdpplot[[i]][[2]]+pdpplot[[i]][[3]]+pdpplot[[i]][[4]]+
    plot_layout(ncol=2,width=c(2,2),height=c(2,2))
  part3<-mdplot[[i]]+part2+plot_layout(width=c(2.5,4.5))+
    plot_annotation(tag_levels = list(c('c','d','e','f','g')))

  ggsave(plot=part1,file=paste0('绘图记录draw/Dis/',label[i],'-1.pdf'),width=13,height=8)
  ggsave(plot=part3,file=paste0('绘图记录draw/Dis/',label[i],'-2.pdf'),width=13,height=7.7)
}

# layout <- '
# AAABBBB
# AAABBBB
# AAABBBB
# CCCDDEE
# CCCDDEE
# CCCFFGG
# CCCFFGG
# '
# wrap_plots(A = miplot[[1]], B = fiplot[[1]], c = mdplot[[1]], design = layout)

ic<-c(1,7,9,3,3,7,13,14,15)
v1c=c(rep('Zeta',4),rep('SSA',2),rep('D',3))
v2c=c(rep('SSA',4),rep('L',2),rep('L',3))
 
netpdpplot<-list()
for (j in 1:9){
  i<-ic[j]
  v1<-v1c[j]
  v2<-v2c[j]
  
  # if (i<=12){
  #   data<-read.xlsx('imm/RF20210202.xlsx',i+1,header=TRUE)
  #   colnames(data)<-colindex
  #   # train<-read.xlsx('imm/ss-index-all.xlsx',i)$X0
  #   # data_train<-data
  #   # data_test<-data[-train,]
  #   seed<-rep(1,12)
  #   seed[8]<-2
  #   seed[12]<-8
  #   set.seed(seed[i])
  #   rf<-randomForest(Index~.,data=data,importance=TRUE,proximity=T,ntree=500,mtry=5)
  # } else {
  #   data<-read.xlsx('burden/clearance2021.xlsx',i-10,header=TRUE)[-1]
  #   colnames(data)<-colindex[-c(2,24,25)]
  #   # train<-read.xlsx('burden/ss-index-all.xlsx',i-12)$X0
  #   # data_train<-data[train,]
  #   # data_test<-data[-train,]
  #   seed<-c(1,1,2)
  #   set.seed(seed[i-12])
  #   rf<-randomForest(Index~.,data=data,importance=TRUE,proximity=T,ntree=500,mtry=5)
  # }
  data<-datalist[[i]]
  rf<-randomForest(Index~.,data=data,importance=TRUE,proximity=T,ntree=500,mtry=5)
  par<-pdp::partial(rf,pred.var = c(v1, v2), chull = TRUE, progress = "text")
  if (j==6) { par<-par[-which(par$L>15000),] }
  
  netpdpplot[[j]]<-local({
    par=par
    ggplot(par, aes(x = par[[1L]], y = par[[2L]],
                  z = par[["yhat"]], fill = par[["yhat"]])) +
      geom_tile()+
      geom_contour(color = 'white')+
      viridis::scale_fill_viridis(name =label[i], option = 'D') +
      theme_bw()+
      xlab(colnames(par)[1])+
      ylab(colnames(par)[2])+
      theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank())+
      theme(axis.line=element_line(color='black'),axis.ticks.length=unit(0.3,'line'))+
      theme(legend.position = c(0.9,0.8))
      #scale_x_continuous(limits = c(min(par$Zeta),60))
  #ggsave(paste0('plot/netpdp/',label[i],'-',v1,'-',v2,'.pdf'),width=5,height=5)
  })
}
for (i in 1:9){
netpdpplot[[i]]<-netpdpplot[[i]]+
  theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank())+
  theme(axis.line=element_line(color='black'),axis.text = element_text(size = rel(0.6)),
        axis.ticks.length=unit(0.3,'line'),axis.title = element_text(size = rel(0.6)))+
  theme(legend.key.size = unit(0.5,'line'),legend.title = element_text(size=rel(0.6)),
        legend.text = element_text(size=rel(0.5)),legend.position = c(0.88,0.85))
}
netpdprda<-netpdpplot[[1]]+netpdpplot[[2]]+netpdpplot[[3]]+
            netpdpplot[[4]]+netpdpplot[[5]]+netpdpplot[[6]]+
            netpdpplot[[7]]+netpdpplot[[8]]+netpdpplot[[9]]+
            plot_layout(ncol=3,widths=rep(3,9),height=rep(3.9))
save(netpdpplot,file='Rda/netpdp.rda')
ggsave(file='plot/figure-pdp.pdf',width=9,height=9)


#####################################################################
#####                    permutation test                       #####  my-self
#####################################################################

#####################################################################
#####                    Correlation mat                        #####  Internet
#####################################################################

#####################################################################
#####                    Tabplot for data                       #####  which?
#####################################################################

#####################################################################
#####                    Feature shuffle                        #####  my-self
#####################################################################

#setwd('??your path??/code')
data<-read.xlsx('imm/il1b.xlsx',2)

rmse<-read.xlsx('imm/all-rf-cor.xlsx',6)[1:10,5]
rmse_test.mean<-mean(rmse)

ggplot(data=data,aes(x=Observe,y=Predict,color=type,
                     shape=type,fill=type))+
  geom_abline(intercept=0,slope=1,size=1,color='black')+
  geom_abline(intercept=rmse_test.mean,slope=1,size=0.5,linetype="dashed",color='black')+
  geom_abline(intercept=0-rmse_test.mean,slope=1,size=0.5,linetype="dashed",color='black')+
  geom_point(size=1.5)+
  scale_x_continuous(limits=c(-0.5,1))+
  scale_y_continuous(limits=c(-0.5,1))+
  coord_fixed(ratio=1)+
  scale_shape_manual(name="Data Source",
                     values=c(16,17,18))+
  scale_colour_manual(name="Data Source",
                      values=c("#7ae07a","#e07b7b",'#7b7be0'))+
  theme_bw()+
  theme(axis.line=element_line(color='black'),
        axis.ticks.length=unit(0.5,'line'))+
  #axis.text = element_blank())+
  xlab(NULL)+
  ylab(NULL)+
  theme(panel.grid.major = element_blank(),panel.grid.minor = element_blank())

ggsave('plot/val-il-1b.pdf',width=3.5,height=3.5)


